Internal Edge Impulse fork of ESP-NN. Derived from https://github.com/edgeimpulse/esp-nn/commit/6b3ef8e226a05554a6d874f6456f5ca1771c01c2.
